(function(){
    'use strict';

    angular
    .module('game', ['ui.router'])
    .config(routesConfig);

    function routesConfig($stateProvider){
        $stateProvider
        .state('home_game', {
            templateUrl: 'templates/home.html',
            controller: 'homeController',
            controllerAs: 'vm',
        })

        .state('start_game', {
            templateUrl: 'templates/start.html',
            controller: 'startController',
            controllerAs: 'vm',
            params: {model: null}
        })

    }
})();
