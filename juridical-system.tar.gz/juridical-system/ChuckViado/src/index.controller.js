(function(){
    'use strict';

    angular
    .module('game')
    .controller('indexController', indexController);

    function indexController($state){
        var vm = this;

        init();        
        function init(){
            $state.go('home_game');
        }
        
    }
})();