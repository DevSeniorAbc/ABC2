(function(){
    'use strict';

    angular
    .module('game')
    .controller('homeController', homeController);

    function homeController($state){
        var vm = this;
        vm.model = null;
        
        
        vm.console1 = console1;


        function console1(){
          $state.go('start_game', {model: vm.model})
        }

    }
})();