(function(){
    'use strict';

    angular
    .module('game')
    .controller('startController', startController);

    function startController($state, $stateParams, $scope){
        var vm = this;

        // iniciando as variaveis
        vm.player1 = 'X';
        vm.player2 = 'O';
        vm.currentPlayer = null;
        vm.currentPlayerName = null;
        vm.player1played = [];
        vm.player2played = [];
        vm.player1Scores = 0;
        vm.player2Scores = 0;
        vm.game = [
            {},{},{}, // posicoes 1,2,3
            {},{},{}, // posicoes 4,5,6  
            {},{},{}, // posicoes 7,8,9
       ]
        
        // iniciando as funçoes
        vm.clickIn = clickIn;
        vm.verifyWinner = verifyWinner;
        vm.clearArray = clearArray;
        
        init();        
        function init(){
            vm.model = $stateParams.model;
            vm.currentPlayer =  vm.player1;
            vm.currentPlayerName = vm.model.player1Name;
       }

       // limpa o array e seta o jogador 1 para iniciar
       function clearArray(){
           //força uma atualizaçao
           $scope.$apply(function () {
            //zera o array
            for(var x in vm.game) {
                vm.game[x].id = '' ;
            }
            vm.currentPlayer =  vm.player1;
        });
       }
       
       function verifyWinner(player, name){
            if(vm.game[0].id == player && vm.game[1].id == player && vm.game[2].id == player || vm.game[3].id == player && vm.game[4].id == player && vm.game[5].id == player || vm.game[6].id == player && vm.game[7].id == player && vm.game[8].id == player ||
               vm.game[0].id == player && vm.game[3].id == player && vm.game[6].id == player || vm.game[1].id == player && vm.game[4].id == player && vm.game[7].id == player || vm.game[2].id == player && vm.game[5].id == player && vm.game[8].id == player ||
               vm.game[0].id == player && vm.game[4].id == player && vm.game[8].id == player || vm.game[2].id == player && vm.game[4].id == player && vm.game[6].id == player){
                    
                setTimeout(function(){ 
                        alert("Parabêns você ganhou " + name + "!");
                        if(player == vm.player1){
                            vm.player1Scores++;
                        }else {
                            vm.player2Scores++;
                        }
                        vm.clearArray();
                }, 300);     
                
                return true
            } else if(vm.player1played.length + vm.player2played.length == 9){
                setTimeout(function(){ 
                    alert("velha ");
                    vm.clearArray();
                }, 300);   
            }
        }
       
       function clickIn(id, $index){
            if(vm.currentPlayer == vm.player1){
                if( vm.game[$index].id == vm.player1 ||  vm.game[$index].id == vm.player2){
                    //toastr
                } else {
                    //seta valor do campo com X
                    vm.game[$index].id = vm.player1;
                    //passa vez para proximo jogador
                    vm.currentPlayer = vm.player2;
                    //salva no array as casas onde foi marcado X
                    vm.player1played.push($index)
                    vm.verifyWinner(vm.player1, vm.model.player1Name)
                    //mostra o nome de quem deve jogar
                    vm.currentPlayerName = vm.model.player2Name;
                }
              
            } else {
                if( vm.game[$index].id == vm.player1 ||  vm.game[$index].id == vm.player2){
                   //toastr
                } else {
                    //seta valor do campo com O
                    vm.game[$index].id = vm.player2;
                    //passa vez para proximo jogador
                    vm.currentPlayer = vm.player1;
                    //salva no array as casas onde foi marcado O
                 9
                    vm.verifyWinner(vm.player2, vm.model.player2Name)
                    //mostra o nome de quem deve jogar
                    vm.currentPlayerName = vm.model.player1Name;
                }
            }
        }     
    }
})();