(function () {
    'use strict'

    angular
        .module('myApp' , ['ui.router'] )
        .config(routesConfig)

        function routesConfig($stateProvider){
            $stateProvider

            .state('home' , {
                templateUrl: 'pages/home/home.html',                
            })

            .state('formulario' , {
                templateUrl: 'pages/formulario/formulario_peticoes.html',
            })


        }
})