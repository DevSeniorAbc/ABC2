angular
    .module('myApp' , [])
    .controller('adm_dates' , function ($scope, $http){
        
        var vm  = this  ;

        init(); 

        function init() {
            $http({
                method: 'GET',
                url: 'http://localhost:3000/bank_search'
            }).then(function sucessCallback(response){
                console.log("Response --> " ,  response) ;
                vm.result = response.data.result ; 
            },function errorCallback(response){
                return vm.resultError = response
            })                              
        }
    })
  

    