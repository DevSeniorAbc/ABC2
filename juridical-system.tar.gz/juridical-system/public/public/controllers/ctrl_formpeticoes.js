angular
    .module('myApp' , ['ngMask'])
    .controller('CtrlFormReq' , function($scope , $http) {

        const vm = this ; 

        vm.dates = {
            
        }

        var onSucess = function (data , status , headers , config){
            vm.data = data  ; 
        }
        
        var onErros = function (data , status , headers , config ) {
            vm.data = status ; 
        }

        $http.post('/cadastro' , )

        
         

    } )