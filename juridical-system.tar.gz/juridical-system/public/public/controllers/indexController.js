(function () {
    'use strict'

    angular
    .module('myApp')
    .controller('indexController' , indexController);

    function indexController ($state) {
        var vm = this 

        init() ; 

        function init () {
            $state.go('home')
        }
    }
})