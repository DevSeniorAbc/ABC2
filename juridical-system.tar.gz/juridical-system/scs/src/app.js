const express = require ('express')  ; 
const bodyParser = require ('body-parser')  ; 
const app = express() ; 
app.use(bodyParser.json())  ; 
app.use(bodyParser.urlencoded({extended: false})) ; 
app.use(express.static(__dirname + '/public')) ;
require('./routes/home')(app);
require('./routes/form_ger_pet')(app);
require('./routes/login')(app);
require('./routes/cadastro_usuario')(app);
require('./routes/adm_dates')(app)

app.listen(3000 , function() {
    console.log("Serv Ok")
})
