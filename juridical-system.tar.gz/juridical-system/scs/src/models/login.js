const mongoose = require ('../config/conexao')  ; 
const byctipt = require ('bcryptjs') ; 

const Usuarios = new mongoose.Schema ({
    nome:{
        type: String,
        required: true
    },

    email:{
        type: String,
        required: true,
        unique: true,
        lowercase: true
    },

    senha:{
        type: String,
        required: true,
        select: false
    }
})

Usuarios.pre('save'  , async function (next) {
    const hash = await byctipt.hash(this.senha,10) ; 
    console.log("hash" , hash);
    this.senha = hash ; 


    next()
})


const Usuario = mongoose.model('Usuarios' , Usuarios) ; 
module.exports = Usuario