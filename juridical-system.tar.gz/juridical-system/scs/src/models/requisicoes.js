const mongoose = require ("../config/conexao");
var data =new Date;
var mes = data.getMonth() ; 
var data_send_bd = ("Enviada em " + data.getDate()+"/"+(mes+1)+"/"+data.getFullYear() +  " às " + data.getHours() +":" +data.getMinutes() ) ; 

const Requisicoes = new mongoose.Schema ({
nome: {
type: String,
required: true,
max:50
},

telefone: {
type: String,
required: true,
max:12
},

email: {
type: String,
required: true,
max: 40,
unique: true
},


adverso: {
type: String,
required: true, 
max: 25
}, 

descricao: {
type: String,
required: true,
max: 30
},

data_da_requisicao: {
type: String, 
required:true,
default: data_send_bd
},

resolvido:{
type: String,
required:true,
default: "Não"
}
}) ; 

const Requisicao = mongoose.model('Requisicoes' , Requisicoes) ; 
module.exports = Requisicao