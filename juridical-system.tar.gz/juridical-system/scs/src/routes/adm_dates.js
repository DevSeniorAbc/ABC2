const express = require ('express') ; 
const router  = express.Router(); 


router.get('/dados_requisicoes' ,  async (req , res ) => {
    res.sendfile('dados.html' , {root: './public/views/dates_adm'});
})


module.exports = app => app.use('/' , router)