const express = require ('express') ; 
const router = express.Router();
const Usuario = require ('../models/login');


/* GET --> Responde Arquivo*/
router.get('/cadastro_usuario' , async (req , res) =>{
    res.sendfile('cadastro_usuario.html' , {root: './public/views/cadastro_usuario'});
})


router.post('/cadastro_usuario' , async (req , res ) => {
        const {email} = req.body
  try {

    if (await Usuario.findOne({email}))
        return res.status(401).send({mensagem: "Email já cadastrado !"})

      const usuario  = await Usuario.create(req.body);
      res.send({usuario})
  }catch(err){
        console.log("Ocorreu o seguinte erro -->" , err)
        res.status(400).send({mensagem: "Erro no Cadastro "})  ;
  }

})


module.exports = app => app.use('/' , router) ; 