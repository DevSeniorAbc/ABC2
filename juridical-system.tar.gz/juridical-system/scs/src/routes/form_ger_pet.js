var express = require ('express') ; 
var router = express.Router() ; 
var Requisicao = require ('../models/requisicoes')  ;


router.get ('/formulario' , async (req , res)  => {
    res.sendFile('formulario_peticoes.html' , {root: './public/views/formulario'})  ; 
}) ; 


router.get ('/bank_search' , async  (req , res) => {
  try {
    const result = await Requisicao.find({})
    res.send({result}) ; 
  }catch(err){
    res.send({message: "error"})
  }
})

router.post('/formulario', async  (req , res ) => {
    try{
      const requisicao = await Requisicao.create(req.body);
      res.send({requisicao})
    }catch (err){
      console.log("Ocorreu o seguinte erro --> " , err) ; 
      return res.status(400).send({error : "Falha no Registro"})
   }
})


module.exports = app => app.use('/', router); 

