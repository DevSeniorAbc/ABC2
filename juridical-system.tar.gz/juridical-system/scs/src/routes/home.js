var express = require('express') ; 
var router = express.Router() ; 


router.get('/' , async (req , res ) => {
    res.sendFile('home.html'  , {root: './public/views/home'})
});  

module.exports = app => app.use('/' , router) ; 