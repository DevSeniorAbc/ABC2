const  express = require ('express') ; 
const router  = express.Router(); 




router.get('/login' , async (req , res ) => {
    res.sendFile('login.html' , {root: './public/views/tela_login'})
})



router.post('/login' , )

module.exports = app => app.use('/' , router)  ;
